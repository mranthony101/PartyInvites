﻿using System;
using com.clover.remotepay.sdk;
using com.clover.remotepay.transport;
using iTicketCCProcessor.Infrastructure;
using System.Drawing;
using System.Threading;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;

namespace iTicketCCProcessor.Entities
{
	public class Clover : IProvider
	{

		#region Enumerations

		/// <summary>
		/// An enumeration of card entry types.
		/// </summary>
		private enum CardEntryType
		{
			Swiped,
			Keyed,
			Voice,
			Vaulted,
			OfflineSwiped,
			OfflineKeyed,
			EMVContact,
			EMVContactless,
			MSDContactless,
			PinPadManualEntry
		}

		#endregion Enumerations

		#region Fields
		ICloverConnector cloverConnector;
		//SynchronizationContext uiThread;
		bool Connected = false;

		public int CardEntryMethod { get; private set; }

		public SaleResponse CloverResponse { get; set; }

		bool cancled = false;

		bool failed = false;

		private float scale = 0.2F;

		#endregion

		#region Constructor
		public Clover()
		{
			
		}
		#endregion 




		#region Methods
		public bool Credit()
		{
			return true;
		}

		public bool InitializeDevice(CloverDeviceConfiguration config)
		{
			try
			{
				if (cloverConnector != null)
				{
					cloverConnector.RemoveCloverConnectorListener(this);

					OnDeviceDisconnected(); // for any disabling, messaging, etc.
											//SaleButton.Enabled = false; // everything can work except Pay
					cloverConnector.Dispose();
				}

				cloverConnector = new CloverConnector(config);
				cloverConnector.InitializeConnection();

				cloverConnector.AddCloverConnectorListener(this);

				return true;
			}
			catch (Exception ex)
			{
				Console.WriteLine();
				return false;
			}
		}

		public bool InitializeDevice()
		{
			throw new NotImplementedException();
		}

		public void OnAuthResponse(AuthResponse response)
		{
			throw new NotImplementedException();
		}

		public void OnCapturePreAuthResponse(CapturePreAuthResponse response)
		{
			throw new NotImplementedException();
		}

		public void OnCloseoutResponse(CloseoutResponse response)
		{
			throw new NotImplementedException();
		}

		public void OnConfirmPaymentRequest(ConfirmPaymentRequest request)
		{
			cloverConnector.AcceptPayment(request.Payment);
		}

		public void OnDeviceActivityEnd(CloverDeviceEvent deviceEvent)
		{
			throw new NotImplementedException();
		}

		public void OnDeviceActivityStart(CloverDeviceEvent deviceEvent)
		{
			throw new NotImplementedException();
		}

		public void OnDeviceConnected()
		{
			//throw new NotImplementedException();
		}

		public void OnDeviceDisconnected()
		{
			//throw new NotImplementedException();
		}

		public void OnDeviceError(CloverDeviceErrorEvent deviceErrorEvent)
		{
			//throw new NotImplementedException();
		}

		public void OnDeviceReady(MerchantInfo merchantInfo)
		{
			//throw new NotImplementedException();
		}

		public void OnManualRefundResponse(ManualRefundResponse response)
		{
			if (response.Success)
			{
				Console.WriteLine("Manual Refund Successful");
			}
		}

		public void OnPreAuthResponse(PreAuthResponse response)
		{
			throw new NotImplementedException();
		}

		public void OnPrintManualRefundDeclineReceipt(PrintManualRefundDeclineReceiptMessage printManualRefundDeclineReceiptMessage)
		{
			throw new NotImplementedException();
		}

		public void OnPrintManualRefundReceipt(PrintManualRefundReceiptMessage printManualRefundReceiptMessage)
		{
			throw new NotImplementedException();
		}

		public void OnPrintPaymentDeclineReceipt(PrintPaymentDeclineReceiptMessage printPaymentDeclineReceiptMessage)
		{
			throw new NotImplementedException();
		}

		public void OnPrintPaymentMerchantCopyReceipt(PrintPaymentMerchantCopyReceiptMessage printPaymentMerchantCopyReceiptMessage)
		{
			throw new NotImplementedException();
		}

		public void OnPrintPaymentReceipt(PrintPaymentReceiptMessage printPaymentReceiptMessage)
		{
			throw new NotImplementedException();
		}

		public void OnPrintRefundPaymentReceipt(PrintRefundPaymentReceiptMessage printRefundPaymentReceiptMessage)
		{
			throw new NotImplementedException();
		}

		public void OnReadCardDataResponse(ReadCardDataResponse response)
		{
			throw new NotImplementedException();
		}

		public void OnRefundPaymentResponse(RefundPaymentResponse response)
		{
			if (response.Success)
			{
				Console.WriteLine("Success");
			}
		}

		public void OnRetrievePendingPaymentsResponse(RetrievePendingPaymentsResponse response)
		{
			throw new NotImplementedException();
		}

		public void OnSaleResponse(SaleResponse response)
		{
			if (response.Success)
			{
				CloverResponse = response; 
			}
			else if(response.Result.Equals(ResponseCode.CANCEL))
			{
				cancled = true;
			}
			else if(response.Result.Equals(ResponseCode.FAIL))
			{
				failed = true;
			}
		}

		public void OnTipAdded(TipAddedMessage message)
		{
			throw new NotImplementedException();
		}

		public void OnTipAdjustAuthResponse(TipAdjustAuthResponse response)
		{
			throw new NotImplementedException();
		}

		public void OnVaultCardResponse(VaultCardResponse response)
		{
			throw new NotImplementedException();
		}

		public void OnVerifySignatureRequest(VerifySignatureRequest request)
		{
			request.Accept();
		}

		public void OnVoidPaymentResponse(VoidPaymentResponse response)
		{
			if (response.Success)
			{
				Console.WriteLine("Payment Successfully Voided");
			}
		}

		public bool Sale()
		{
			try
			{
				SaleRequest request = new SaleRequest();
				request.ExternalId = ExternalIDUtil.GenerateRandomString(32);

				//request.CardEntryMethods = CardEntryMethod;
				request.CardNotPresent = false;
				request.Amount = 1244;
				request.TipAmount = 0;
				request.TaxAmount = 0;
				request.DisablePrinting = false;

				cloverConnector.Sale(request);

				int count = 0;
				while(count < 30)
				{
					Thread.Sleep(500);
					if (CloverResponse != null)
					{
						if (CloverResponse.Success)
						{
							this.CreateSignatureBitmap(CloverResponse.Signature, false);
							return true;
						}
						else if(!CloverResponse.Success)
						{
							return false;
						}
					}
					else if (CloverResponse == null)
					{
						if (cancled || failed)
						{
							return false;
						}
					}
						count++;
				}
				return false;
			}
			catch
			{
				return false;
			}
		}


		public bool Void()
		{
			throw new NotImplementedException();
		}

		public bool Sale(bool manualEntry)
		{
			try
			{
				SaleRequest request = new SaleRequest();
				request.ExternalId = ExternalIDUtil.GenerateRandomString(32);

				//request.CardEntryMethods = CardEntryMethod;
				request.CardNotPresent = false;
				request.Amount = 1244;
				request.TipAmount = 0;
				request.TaxAmount = 0;
				request.DisablePrinting = false;

				if (manualEntry)
				{
					//got this from Clover example
					int cardEntry = 34824;
					request.CardEntryMethods = cardEntry;
				}

				cloverConnector.Sale(request);

				int count = 0;
				while (count < 45)
				{
					Thread.Sleep(1000);
					if (CloverResponse != null)
					{
						if (CloverResponse.Success)
						{
							this.CreateSignatureBitmap(CloverResponse.Signature, false);
							return true;
						}
						else if (!CloverResponse.Success)
						{
							return false;
						}
					}
					else if (CloverResponse == null)
					{
						if (cancled || failed)
						{
							return false;
						}
					}
					count++;
				}
				return false;
			}
			catch
			{
				return false;
			}
		}

		private void CreateSignatureBitmap(Signature2 signature,
				 bool includeSignatureLine)
		{
			try
			{
				// Check for null signature
				if (signature != null)
				{
					// Instantiate Bitmap object
					using (Bitmap bitmap = new Bitmap(
						(int)(signature.width * scale),
						(int)(signature.height * scale),
						PixelFormat.Format24bppRgb))

					// Instantiate Graphics object from Bitmap object
					using (Graphics graphics = Graphics.FromImage(bitmap))
					{
						graphics.SmoothingMode = SmoothingMode.AntiAlias;
						graphics.Clear(Color.White);

						if (includeSignatureLine)
						{
							// Instantiate border Pen and border
							Pen borderPen = new Pen(Color.DarkGray);
							borderPen.Width = 2.0F;
							Rectangle border = new Rectangle(new Point(0, 0),
									 new System.Drawing.Size(
											 (int)(signature.width * scale),
											 (int)(signature.height * scale)));

							// Draw X symbol
							int xWidth = (int)(signature.width * .1 * .6 * scale);
							int xHeight = (int)(xWidth * 1.5);
							graphics.DrawLine(borderPen,
									 new Point(
											 (int)(signature.width * scale * .1 - xWidth),
											  (int)(signature.height * .6 * scale - xHeight)),
									 new Point(
											 (int)(signature.width * scale * .01) + xWidth,
											 (int)(signature.height * .6 * scale)));
							graphics.DrawLine(borderPen,
									 new Point(
											  (int)(signature.width * scale * .1 - xWidth) + xWidth,
											  (int)(signature.height * .6 * scale - xHeight)),
									 new Point(
											 (int)(signature.width * scale * .01),
											 (int)(signature.height * .6 * scale)));

							// Reset with of border Pen and draw signature line
							borderPen.Width = 1.5F;
							graphics.DrawLine(borderPen,
									 new Point((int)(signature.width * .1 * scale),
											 (int)(signature.height * .6 * scale)),
									 new Point((int)(signature.width * .9 * scale),
											 (int)(signature.height * .6 * scale)));
						}

						// Instantiate signature Pen
						Pen pen = new Pen(Color.Black);
						pen.Width = 1;

						// Draw strokes of signature
						foreach (Signature2.Stroke stroke in signature.strokes)
						{
							if (stroke.points.Count == 1)
							{
								Signature2.Point dot = stroke.points[0];
								Rectangle rect = new Rectangle(
										new Point(dot.x, dot.y), new Size(2, 2));

								graphics.DrawEllipse(pen, rect);
							}
							else if (stroke.points.Count > 1)
							{
								for (int p = 1; p < stroke.points.Count; p++)
								{
									Point point1 = new Point()
									{
										X = (int)(stroke.points[p - 1].x * scale),
										Y = (int)(stroke.points[p - 1].y * scale)
									};
									Point point2 = new Point()
									{
										X = (int)(stroke.points[p].x * scale),
										Y = (int)(stroke.points[p].y * scale)
									};

									graphics.DrawLine(pen, point1, point2);
								}
							}
						}
						// Save the resulting Bitmap
						bitmap.Save(@"C:\Users\Ross Anthony\Pictures\\signature.bmp", ImageFormat.Bmp);
					}
				}
			}
			catch (Exception ex)
			{

			}
		}
		#endregion
	}
}
