﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using iTicketCCProcessor.Entities;
using iTicketCCProcessor.Infrastructure;
using com.clover.remotepay.transport;
using com.clover.remote.order;
using com.clover.sdk.v3.payments;
using System.Windows.Automation.Peers;
using System.Threading;

namespace iTicketCCProcessor
{
	/// <summary>
	/// Interaction logic for CCSaleForm.xaml
	/// </summary>
	public partial class CCSaleForm : Window
	{
		string processorClient;
		IProvider ccClient;

		CloverDeviceConfiguration USBConfig = new USBCloverDeviceConfiguration("__deviceID__", "CloverExamplePOS:1.1.0.2", false, 1);

		public CCSaleForm(string client)
		{ 
			this.processorClient = client;
			InitializeComponent();
			
			if(client.Equals("Clover"))
			{
				ccClient = new Clover();
				ccClient.InitializeDevice(USBConfig);
				//MessageBox.Show("Clover");
			}
			else
			{
				ccClient = new Mock();
				ccClient.InitializeDevice();
				//MessageBox.Show("Mock");
			}
			MoneyLabel.Content = string.Format("$ {0}", "12.44");
			GreenThumb.Visibility = Visibility.Hidden;
			RedThumb.Visibility = Visibility.Hidden;
		}
		
		public CCSaleForm()
		{

		}

		private void SaleButton_Click(object sender, RoutedEventArgs e)
		{
			ClearForm();
			if (ccClient.Sale())
			{
				GreenThumb.Visibility = Visibility.Visible;
				TxStatusLabel.Content = "Sale Successful";
			}
			else
			{
				RedThumb.Visibility = Visibility.Visible;
				TxStatusLabel.Content = "Sale Failed";
			}
			
		}

		private void Manual_Entry_Click(object sender, RoutedEventArgs e)
		{


			if (ccClient.Sale(true))
			{
				GreenThumb.Visibility = Visibility.Visible;
				TxStatusLabel.Content = "Sale Successful";
			}
			else
			{
				RedThumb.Visibility = Visibility.Visible;
				TxStatusLabel.Content = "Sale Failed";
			}

			ClearForm();

		}

		private void CancelButton_Click(object sender, RoutedEventArgs e)
		{
			ClearForm();
		}

		public void ClearForm()
		{
			GreenThumb.Visibility = Visibility.Collapsed;
			RedThumb.Visibility = Visibility.Hidden;
			TxStatusLabel.Content = "";
		}
	}
}
