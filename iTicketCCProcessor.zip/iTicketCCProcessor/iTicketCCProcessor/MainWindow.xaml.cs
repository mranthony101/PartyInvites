﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using com.clover.remotepay.sdk;
using com.clover.remotepay.transport;
using com.clover.remote.order;
using com.clover.sdk.v3.payments;
using System.Threading;
using iTicketCCProcessor.Infrastructure;
using iTicketCCProcessor.Entities;

namespace iTicketCCProcessor
{
	/// <summary>
	/// Interaction logic for MainWindow.xaml
	/// </summary>
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			string processorClient = "Clover";
			string transaction = "Refund";
			if(transaction.Equals("Sale"))
			{
				CCSaleForm form = new CCSaleForm(processorClient);
				this.Hide();
				form.Show();
			}
			else if(transaction.Equals("Refund"))
			{
				CCRefundForm form = new CCRefundForm(processorClient);
				this.Hide();
				form.Show();
			}

			InitializeComponent();

			//uiThread = WindowsFormsSynchronizationContext.Current;
		}


	}
}
