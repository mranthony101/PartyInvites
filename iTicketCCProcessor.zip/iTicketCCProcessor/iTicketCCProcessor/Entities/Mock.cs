﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using com.clover.remotepay.sdk;
using com.clover.remotepay.transport;
using iTicketCCProcessor.Infrastructure;

namespace iTicketCCProcessor.Entities
{
	class Mock : IProvider
	{
        public int Amount
        {
            get
            {
                throw new NotImplementedException();
            }

            set
            {
                throw new NotImplementedException();
            }
        }

        public bool Credit(List<string[]> list, string conString, int dis)
		{
			throw new NotImplementedException();
		}

		public bool InitializeDevice(CloverDeviceConfiguration config)
		{
			throw new NotImplementedException();
		}

		public bool InitializeDevice()
		{
			return true;
		}

		public void OnAuthResponse(AuthResponse response)
		{
			throw new NotImplementedException();
		}

		public void OnCapturePreAuthResponse(CapturePreAuthResponse response)
		{
			throw new NotImplementedException();
		}

		public void OnCloseoutResponse(CloseoutResponse response)
		{
			throw new NotImplementedException();
		}

		public void OnConfirmPaymentRequest(ConfirmPaymentRequest request)
		{
			throw new NotImplementedException();
		}

		public void OnDeviceActivityEnd(CloverDeviceEvent deviceEvent)
		{
			throw new NotImplementedException();
		}

		public void OnDeviceActivityStart(CloverDeviceEvent deviceEvent)
		{
			throw new NotImplementedException();
		}

		public void OnDeviceConnected()
		{
			throw new NotImplementedException();
		}

		public void OnDeviceDisconnected()
		{
			throw new NotImplementedException();
		}

		public void OnDeviceError(CloverDeviceErrorEvent deviceErrorEvent)
		{
			throw new NotImplementedException();
		}

		public void OnDeviceReady(MerchantInfo merchantInfo)
		{
			throw new NotImplementedException();
		}

		public void OnManualRefundResponse(ManualRefundResponse response)
		{
			throw new NotImplementedException();
		}

		public void OnPreAuthResponse(PreAuthResponse response)
		{
			throw new NotImplementedException();
		}

		public void OnPrintManualRefundDeclineReceipt(PrintManualRefundDeclineReceiptMessage printManualRefundDeclineReceiptMessage)
		{
			throw new NotImplementedException();
		}

		public void OnPrintManualRefundReceipt(PrintManualRefundReceiptMessage printManualRefundReceiptMessage)
		{
			throw new NotImplementedException();
		}

		public void OnPrintPaymentDeclineReceipt(PrintPaymentDeclineReceiptMessage printPaymentDeclineReceiptMessage)
		{
			throw new NotImplementedException();
		}

		public void OnPrintPaymentMerchantCopyReceipt(PrintPaymentMerchantCopyReceiptMessage printPaymentMerchantCopyReceiptMessage)
		{
			throw new NotImplementedException();
		}

		public void OnPrintPaymentReceipt(PrintPaymentReceiptMessage printPaymentReceiptMessage)
		{
			throw new NotImplementedException();
		}

		public void OnPrintRefundPaymentReceipt(PrintRefundPaymentReceiptMessage printRefundPaymentReceiptMessage)
		{
			throw new NotImplementedException();
		}

		public void OnReadCardDataResponse(ReadCardDataResponse response)
		{
			throw new NotImplementedException();
		}

		public void OnRefundPaymentResponse(RefundPaymentResponse response)
		{
			throw new NotImplementedException();
		}

		public void OnRetrievePendingPaymentsResponse(RetrievePendingPaymentsResponse response)
		{
			throw new NotImplementedException();
		}

		public void OnSaleResponse(SaleResponse response)
		{
			
		}

		public void OnTipAdded(TipAddedMessage message)
		{
			throw new NotImplementedException();
		}

		public void OnTipAdjustAuthResponse(TipAdjustAuthResponse response)
		{
			throw new NotImplementedException();
		}

		public void OnVaultCardResponse(VaultCardResponse response)
		{
			throw new NotImplementedException();
		}

		public void OnVerifySignatureRequest(VerifySignatureRequest request)
		{
			throw new NotImplementedException();
		}

		public void OnVoidPaymentResponse(VoidPaymentResponse response)
		{
			throw new NotImplementedException();
		}

		public bool Sale()
		{
			Console.WriteLine("Hello");
			Console.ReadKey();
			return true;
		}

		public bool Void()
		{
			throw new NotImplementedException();
		}

		public bool Sale(bool manualEntry)
		{
			throw new NotImplementedException();
		}

        public bool GetProviderRequest()
        {
            throw new NotImplementedException();
        }
    }
}
