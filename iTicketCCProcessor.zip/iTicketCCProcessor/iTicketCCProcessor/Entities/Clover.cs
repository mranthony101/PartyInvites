﻿using System;
using com.clover.remotepay.sdk;
using com.clover.remotepay.transport;
using iTicketCCProcessor.Infrastructure;
using System.Drawing;
using System.Threading;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Collections.Generic;
using System.Data;
using System.Reflection;
using ABP.Common.DAL.SqlServer;
using NLog;
using System.Data.SqlClient;
using System.Globalization;

namespace iTicketCCProcessor.Entities
{
	public class Clover : IProvider
	{
        #region Properties

        public int Amount { get; set; } 

        #endregion

        #region Enumerations

        /// <summary>
        /// An enumeration of card entry types.
        /// </summary>
        private enum CardEntryType
		{
			Swiped,
			Keyed,
			Voice,
			Vaulted,
			OfflineSwiped,
			OfflineKeyed,
			EMVContact,
			EMVContactless,
			MSDContactless,
			PinPadManualEntry
		}

		#endregion Enumerations

		#region Fields
		ICloverConnector cloverConnector;
		//SynchronizationContext uiThread;
		bool Connected = false;

		public int CardEntryMethod { get; private set; }

		public SaleResponse CloverResponse { get; set; }

        public RefundPaymentResponse CloverRefund { get; set; }

        public VoidPaymentResponse CloverVoid { get; set; }

        bool cancled = false;

		bool failed = false;

		private float scale = 0.2F;

		Thread thread;

        Thread localPost;

		private static string localConn = @"Data Source=.\SQLExpress;Initial Catalog=iTicketPOS;Integrated Security=True";

		QueryHandler localHandler = new QueryHandler(localConn);

        QueryHandler cloudHandler;

        string siteCode;

        string guestName;

        string clerkName;

        int transactionID;

        decimal batchTotal;

        bool fullRefund = false;

        int batchNum;

        string amount;
        string authCode;
        string cardTx;
        string cardHolder;
        string entryType;
        string cardNum;
        string type;
        string externalPayID;
        string orderID;

        #endregion

        #region Constructor
        public Clover(string connParam)
		{
            cloudHandler = new QueryHandler(connParam);
		}

        public Clover()
        {

        }
		#endregion 

		#region Methods
		public bool Credit(List<string[]> list, string conString, int district)
		{
            try
            {
                foreach(var element in list)
                {
                    string cardNum = element[0];
                    string cardHoldName = element[1];
                    string cardIssuer = element[2];
                    decimal availBal = decimal.Parse(element[3]);
                    decimal chargeBal = string.IsNullOrEmpty(element[4]) ? 0 : decimal.Parse(element[4]);

                    string query = string.Format("Select Date, CommCardType, IntrnSeqNum From D{0}_CC Where Account = '{1}' and Issuer = '{2}' and Amount = {3}",
                                                                    district, cardNum, cardIssuer, availBal);
                    DataTable ccInfo = cloudHandler.ExecuteDataTable(query);

                    DateTime currentDate = DateTime.Now;
                    DateTime txDate = ccInfo.Rows[0].Field<DateTime>("Date");
                    string paymentID = ccInfo.Rows[0].Field<string>("CommCardType");
                    string orderID = ccInfo.Rows[0].Field<string>("IntrnSeqNum");

                    if (txDate.Date == currentDate.Date)
                    {
                        VoidPaymentRequest voidRequest = new VoidPaymentRequest();

                        voidRequest.PaymentId = paymentID;
                        voidRequest.OrderId = orderID;
                        voidRequest.EmployeeId = "11111";
                        voidRequest.VoidReason = "USER_CANCEL";

                        cloverConnector.VoidPayment(voidRequest);
                    }
                    else
                    {
                        RefundPaymentRequest requestRef = new RefundPaymentRequest();
                        requestRef.PaymentId = paymentID;
                        requestRef.OrderId = orderID;

                        string decToInt = chargeBal.ToString();
                        int amtToCharge = DecimalToInt(decToInt);
                        requestRef.Amount = amtToCharge;
                        requestRef.FullRefund = false;

                        cloverConnector.RefundPayment(requestRef);
                    }


                }
                return true;
            }
            catch (Exception)
            {
                throw;
            }
		}

        public int DecimalToInt(string number)
        {
            try
            {
                int decIndex = number.IndexOf('.');
                string firstH = number.Substring(0, decIndex);
                string secondH = number.Substring(decIndex + 1);
                int returnVal = int.Parse(firstH + secondH);

                return returnVal;
            }
            catch
            {
                return 0;
            }
        }

		public bool InitializeDevice(CloverDeviceConfiguration config)
		{
			try
			{
				if (cloverConnector != null)
				{
					cloverConnector.RemoveCloverConnectorListener(this);

					OnDeviceDisconnected(); // for any disabling, messaging, etc.
											//SaleButton.Enabled = false; // everything can work except Pay
					cloverConnector.Dispose();
				}

				cloverConnector = new CloverConnector(config);
				cloverConnector.InitializeConnection();

				cloverConnector.AddCloverConnectorListener(this);

				return true;
			}
			catch (Exception ex)
			{
				Console.WriteLine();
				return false;
			}
		}

		public bool Sale()
		{
			try
			{
				SaleRequest request = new SaleRequest();
				request.ExternalId = ExternalIDUtil.GenerateRandomString(32);

				//request.CardEntryMethods = CardEntryMethod;
				request.CardNotPresent = false;
                request.Amount = Amount;
				request.TipAmount = 0;
				request.TaxAmount = 0;
				request.DisablePrinting = false;

				cloverConnector.Sale(request);

				int count = 0;
				while (count < 30)
				{
					Thread.Sleep(500);
					if (CloverResponse != null)
					{
						if (CloverResponse.Success)
						{
                            localPost = new Thread(delegate ()
                            {
                                PushCCInfoToLocal();
                            });
                            localPost.Start();

                            this.CreateSignatureBitmap(CloverResponse.Signature, false);
							return true;
						}
						else if (!CloverResponse.Success)
						{
							return false;
						}
					}
					else if (CloverResponse == null)
					{
						if (cancled || failed)
						{
							return false;
						}
					}
					count++;
				}
				return false;
			}
			catch
			{
				return false;
			}
		}


		public bool Void()
		{
			throw new NotImplementedException();
		}

		public bool Sale(bool manualEntry)
		{
			try
			{
				SaleRequest request = new SaleRequest();
				request.ExternalId = ExternalIDUtil.GenerateRandomString(32);

				//request.CardEntryMethods = CardEntryMethod;
				request.CardNotPresent = false;
				request.Amount = 1244;
				request.TipAmount = 0;
				request.TaxAmount = 0;
				request.DisablePrinting = false;

				if (manualEntry)
				{
					//got this from Clover example
					int cardEntry = 34824;
					request.CardEntryMethods = cardEntry;
				}

				cloverConnector.Sale(request);

				int count = 0;
				while (count < 45)
				{
					Thread.Sleep(1000);
					if (CloverResponse != null)
					{
						if (CloverResponse.Success)
						{
                            localPost = new Thread(delegate ()
                            {
                                PushCCInfoToLocal();
                            });
                            localPost.Start();

                            this.CreateSignatureBitmap(CloverResponse.Signature, false);
                            //PushResponseToLocal(CloverResponse);
                            cloverConnector.ShowWelcomeScreen();
							return true;
						}
						else if (!CloverResponse.Success)
						{
							return false;
						}
					}
					else if (CloverResponse == null)
					{
						if (cancled || failed)
						{
							return false;
						}
					}
					count++;
				}
				return false;
			}
			catch
			{
				return false;
			}
		}

		private void CreateSignatureBitmap(Signature2 signature,
				 bool includeSignatureLine)
		{
			try
			{
				// Check for null signature
				if (signature != null)
				{
					// Instantiate Bitmap object
					using (Bitmap bitmap = new Bitmap(
						(int)(signature.width * scale),
						(int)(signature.height * scale),
						PixelFormat.Format24bppRgb))

					// Instantiate Graphics object from Bitmap object
					using (Graphics graphics = Graphics.FromImage(bitmap))
					{
						graphics.SmoothingMode = SmoothingMode.AntiAlias;
						graphics.Clear(Color.White);

						if (includeSignatureLine)
						{
							// Instantiate border Pen and border
							Pen borderPen = new Pen(Color.DarkGray);
							borderPen.Width = 2.0F;
							Rectangle border = new Rectangle(new Point(0, 0),
									 new System.Drawing.Size(
											 (int)(signature.width * scale),
											 (int)(signature.height * scale)));

							// Draw X symbol
							int xWidth = (int)(signature.width * .1 * .6 * scale);
							int xHeight = (int)(xWidth * 1.5);
							graphics.DrawLine(borderPen,
									 new Point(
											 (int)(signature.width * scale * .1 - xWidth),
											  (int)(signature.height * .6 * scale - xHeight)),
									 new Point(
											 (int)(signature.width * scale * .01) + xWidth,
											 (int)(signature.height * .6 * scale)));
							graphics.DrawLine(borderPen,
									 new Point(
											  (int)(signature.width * scale * .1 - xWidth) + xWidth,
											  (int)(signature.height * .6 * scale - xHeight)),
									 new Point(
											 (int)(signature.width * scale * .01),
											 (int)(signature.height * .6 * scale)));

							// Reset with of border Pen and draw signature line
							borderPen.Width = 1.5F;
							graphics.DrawLine(borderPen,
									 new Point((int)(signature.width * .1 * scale),
											 (int)(signature.height * .6 * scale)),
									 new Point((int)(signature.width * .9 * scale),
											 (int)(signature.height * .6 * scale)));
						}

						// Instantiate signature Pen
						Pen pen = new Pen(Color.Black);
						pen.Width = 1;

						// Draw strokes of signature
						foreach (Signature2.Stroke stroke in signature.strokes)
						{
							if (stroke.points.Count == 1)
							{
								Signature2.Point dot = stroke.points[0];
								Rectangle rect = new Rectangle(
										new Point(dot.x, dot.y), new Size(2, 2));

								graphics.DrawEllipse(pen, rect);
							}
							else if (stroke.points.Count > 1)
							{
								for (int p = 1; p < stroke.points.Count; p++)
								{
									Point point1 = new Point()
									{
										X = (int)(stroke.points[p - 1].x * scale),
										Y = (int)(stroke.points[p - 1].y * scale)
									};
									Point point2 = new Point()
									{
										X = (int)(stroke.points[p].x * scale),
										Y = (int)(stroke.points[p].y * scale)
									};

									graphics.DrawLine(pen, point1, point2);
								}
							}
						}
						// Save the resulting Bitmap
						bitmap.Save(@"C:\Users\Ross Anthony\Pictures\\signature.bmp", ImageFormat.Bmp);
					}
				}
			}
			catch (Exception ex)
			{

			}
		}

		private void PushResponseToLocal(SaleResponse response)
		{
			localHandler.ExecuteNonQuery("Drop Table TempResponse");

			List<string[]> list = new List<string[]>();
			amount = (response.Payment.amount.ToString());
			authCode = (response.Payment.cardTransaction.authCode.ToString());
			cardTx = (response.Payment.cardTransaction.cardType.ToString());
			cardHolder = (response.Payment.cardTransaction.cardholderName.ToString());
			entryType = (response.Payment.cardTransaction.entryType.ToString());
			cardNum = "123456*****" + response.Payment.cardTransaction.last4.ToString();
			type = (response.Payment.cardTransaction.type.ToString());
			externalPayID = (response.Payment.id.ToString());
			orderID = (response.Payment.order.id.ToString());

			string[] columnArray = new string[] 
			{"Amount", "AuthCode", "Card Type", "Card Holder Name", "Entry Type", "Card Num", "Type", "ExernalID", "OrderId" };
			list.Add(new string[] { amount,authCode,cardTx,cardHolder,entryType,cardNum,type,externalPayID,orderID });

			DataTable reponseInfoTbl = ConvertListToDataTable(list,columnArray);

			string createQuery = CreateLocalTempTable("TempResponse", reponseInfoTbl);
			localHandler.ExecuteNonQuery(createQuery);
			BulkToLocal(reponseInfoTbl);
		}

		private void BulkToLocal(DataTable dt)
		{
			using (SqlBulkCopy bulk = new SqlBulkCopy(localConn))
			{
				bulk.DestinationTableName = "TempResponse";
				try
				{
					bulk.WriteToServer(dt);
				}
				catch(Exception ex)
				{
					throw ex;
				}
			}
		}

        private void PushCCInfoToLocal()
        {
            string time = DateTime.Now.ToString("hh:mm:ss tt");
            string currentDate = DateTime.Now.ToShortDateString();

            string sqlTable = localHandler.ExecuteScalar<string>("SELECT top 1 TABLE_NAME FROM INFORMATION_SCHEMA.TABLES where table_name like '%_CC%'");

            decimal decAmount = (decimal)Amount / 100;

            string query = string.Format("Insert Into {0} (SiteCode, ShiftDate, Date, Time, TXID, Clerk, Customer, TranType, Account, Amount, Issuer, Result, CommCardType, " +
                           "AuthCode, IntrnSeqNum, VSBatchNum, BatchTotal, EntryMethod) " +
                           "Values ('{1}','{2}','{3}','{4}',{5},'{6}','{7}','{8}','{9}',{10},'{11}','{12}','{13}','{14}','{15}','{16}',{17},'{18}')"
                           , sqlTable, siteCode,currentDate,currentDate,time, transactionID,clerkName,guestName,"Sale",cardNum, decAmount, cardTx,
                           "CAPTURED",externalPayID,authCode,orderID,batchNum,batchTotal,entryType);

            localHandler.ExecuteNonQuery(query);
        }

		static DataTable ConvertListToDataTable(List<string[]> list,string[] columNames)
		{
			// New table.
			DataTable table = new DataTable();

			// Get max columns.
			int columns = 0;
			foreach (var array in list)
			{
				if (array.Length > columns)
				{
					columns = array.Length;
				}
			}

			// Add columns.
			for (int i = 0; i < columns; i++)
			{
				table.Columns.Add(columNames[i]);
			}

			// Add rows.
			foreach (var array in list)
			{
				table.Rows.Add(array);
			}

			return table;
		}

		public static string CreateLocalTempTable(string tableName, DataTable table)
		{
			string sqlsc;
			sqlsc = "CREATE TABLE " + tableName + "(";
			for (int i = 0; i < table.Columns.Count; i++)
			{
				sqlsc += "\n [" + table.Columns[i].ColumnName + "] ";
				string columnType = table.Columns[i].DataType.ToString();
				switch (columnType)
				{
					case "System.Int32":
						sqlsc += " int ";
						break;
					case "System.Int64":
						sqlsc += " bigint ";
						break;
					case "System.Int16":
						sqlsc += " smallint";
						break;
					case "System.Byte":
						sqlsc += " tinyint";
						break;
					case "System.Decimal":
						sqlsc += " decimal ";
						break;
					case "System.DateTime":
						sqlsc += " datetime ";
						break;
					case "System.String":
					default:
						sqlsc += string.Format(" varchar({0}) ", table.Columns[i].MaxLength == -1 ? "max" : table.Columns[i].MaxLength.ToString());
						break;
				}
				if (table.Columns[i].AutoIncrement)
					sqlsc += " IDENTITY(" + table.Columns[i].AutoIncrementSeed.ToString() + "," + table.Columns[i].AutoIncrementStep.ToString() + ") ";
				if (!table.Columns[i].AllowDBNull)
					sqlsc += " NOT NULL ";
				sqlsc += ",";
			}
			return sqlsc.Substring(0, sqlsc.Length - 1) + "\n)";
		}

        public bool GetProviderRequest()
        {
            try
            {
                DataTable providerInfoTbl = localHandler.ExecuteDataTable("Select * from cloversalerequest");
                Amount = providerInfoTbl.Rows[0].Field<int>("Amount");
                siteCode = providerInfoTbl.Rows[0].Field<string>("SiteCode");
                transactionID = providerInfoTbl.Rows[0].Field<int>("TransactionID");
                guestName = providerInfoTbl.Rows[0].Field<string>("GuestName");
                clerkName = providerInfoTbl.Rows[0].Field<string>("Clerk");
                batchTotal = providerInfoTbl.Rows[0].Field<decimal>("BatchTotal");
                batchNum = providerInfoTbl.Rows[0].Field<int>("VSBatch#");

                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        #endregion

        #region Events
        public bool InitializeDevice()
		{
			throw new NotImplementedException();
		}

		public void OnAuthResponse(AuthResponse response)
		{
			throw new NotImplementedException();
		}

		public void OnCapturePreAuthResponse(CapturePreAuthResponse response)
		{
			throw new NotImplementedException();
		}

		public void OnCloseoutResponse(CloseoutResponse response)
		{
			throw new NotImplementedException();
		}

		public void OnConfirmPaymentRequest(ConfirmPaymentRequest request)
		{
			cloverConnector.AcceptPayment(request.Payment);
		}

		public void OnDeviceActivityEnd(CloverDeviceEvent deviceEvent)
		{
			throw new NotImplementedException();
		}

		public void OnDeviceActivityStart(CloverDeviceEvent deviceEvent)
		{
			throw new NotImplementedException();
		}

		public void OnDeviceConnected()
		{
			//throw new NotImplementedException();
		}

		public void OnDeviceDisconnected()
		{
			//throw new NotImplementedException();
		}

		public void OnDeviceError(CloverDeviceErrorEvent deviceErrorEvent)
		{
			//throw new NotImplementedException();
		}

		public void OnDeviceReady(MerchantInfo merchantInfo)
		{
			//throw new NotImplementedException();
		}

		public void OnManualRefundResponse(ManualRefundResponse response)
		{
			if (response.Success)
			{
				Console.WriteLine("Manual Refund Successful");
			}
		}

		public void OnPreAuthResponse(PreAuthResponse response)
		{
			throw new NotImplementedException();
		}

		public void OnPrintManualRefundDeclineReceipt(PrintManualRefundDeclineReceiptMessage printManualRefundDeclineReceiptMessage)
		{
			throw new NotImplementedException();
		}

		public void OnPrintManualRefundReceipt(PrintManualRefundReceiptMessage printManualRefundReceiptMessage)
		{
			throw new NotImplementedException();
		}

		public void OnPrintPaymentDeclineReceipt(PrintPaymentDeclineReceiptMessage printPaymentDeclineReceiptMessage)
		{
			throw new NotImplementedException();
		}

		public void OnPrintPaymentMerchantCopyReceipt(PrintPaymentMerchantCopyReceiptMessage printPaymentMerchantCopyReceiptMessage)
		{
			throw new NotImplementedException();
		}

		public void OnPrintPaymentReceipt(PrintPaymentReceiptMessage printPaymentReceiptMessage)
		{
			throw new NotImplementedException();
		}

		public void OnPrintRefundPaymentReceipt(PrintRefundPaymentReceiptMessage printRefundPaymentReceiptMessage)
		{
			throw new NotImplementedException();
		}

		public void OnReadCardDataResponse(ReadCardDataResponse response)
		{
			throw new NotImplementedException();
		}

		public void OnRefundPaymentResponse(RefundPaymentResponse response)
		{
			if (response.Success)
			{
                int y = 4;
			}
            else
            {
                int x = 3;
            }
		}

		public void OnRetrievePendingPaymentsResponse(RetrievePendingPaymentsResponse response)
		{
			throw new NotImplementedException();
		}

		public void OnSaleResponse(SaleResponse response)
		{
			if (response.Success)
			{
				CloverResponse = response;
				thread = new Thread(delegate ()
				{
					PushResponseToLocal(CloverResponse);
				});
				thread.Start();

			}
			else if (response.Result.Equals(ResponseCode.CANCEL))
			{
				cancled = true;
			}
			else if (response.Result.Equals(ResponseCode.FAIL))
			{
				failed = true;
			}
		}

		public void OnTipAdded(TipAddedMessage message)
		{
			throw new NotImplementedException();
		}

		public void OnTipAdjustAuthResponse(TipAdjustAuthResponse response)
		{
			throw new NotImplementedException();
		}

		public void OnVaultCardResponse(VaultCardResponse response)
		{
			throw new NotImplementedException();
		}

		public void OnVerifySignatureRequest(VerifySignatureRequest request)
		{
			request.Accept();
		}

		public void OnVoidPaymentResponse(VoidPaymentResponse response)
		{
			if (response.Success)
			{
                int x = 4;
			}
            else
            {
                int x = 4;
            }
		}

       
        #endregion


    }
}
