﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using iTicketCCProcessor.Entities;
using iTicketCCProcessor.Infrastructure;
using com.clover.remotepay.transport;
using com.clover.remote.order;
using com.clover.sdk.v3.payments;
using System.Windows.Automation.Peers;
using System.Threading;
using System.Windows.Threading;

namespace iTicketCCProcessor
{
	/// <summary>
	/// Interaction logic for CCSaleForm.xaml
	/// </summary>
	public partial class CCSaleForm : Window
	{
        #region Properties

        public int Amount { get; set; }

        #endregion

        #region Fields
        /// <summary>
        /// The processor client
        /// </summary>
        string processorClient;

        /// <summary>
        /// The cc client
        /// </summary>
        IProvider ccClient;

        /// <summary>
        /// The usb configuration
        /// </summary>
        CloverDeviceConfiguration USBConfig = new USBCloverDeviceConfiguration("__deviceID__", "CloverExamplePOS:1.1.0.2", false, 1);

        /// <summary>
        /// The thread
        /// </summary>
        Thread thread;

        /// <summary>
        /// The UI thread
        /// </summary>
        SynchronizationContext uiThread;

        /// <summary>
        /// The site code
        /// </summary>
        string siteCode;

        /// <summary>
        /// The tx identifier
        /// </summary>
        int txID;

        /// <summary>
        /// The guest name
        /// </summary>
        string guestName;

        /// <summary>
        /// The clerk name
        /// </summary>
        string clerkName;

        /// <summary>
        /// The tx amount
        /// </summary>
        int txAmount;

        #endregion

        public CCSaleForm(string client)
		{ 
			this.processorClient = client;
			InitializeComponent();
			uiThread = SynchronizationContext.Current;

			if (client.Equals("Clover"))
			{
				ccClient = new Clover();
				ccClient.InitializeDevice(USBConfig);
				//MessageBox.Show("Clover");
			}
			else
			{
				ccClient = new Mock();
				ccClient.InitializeDevice();
				//MessageBox.Show("Mock");
			}


            ccClient.GetProviderRequest();
            Amount = ccClient.Amount;

            decimal decAmount = (decimal)Amount / 100;
            MoneyLabel.Content = string.Format("$ {0}", decAmount.ToString("#####.00"));

			GreenThumb.Visibility = Visibility.Hidden;
			RedThumb.Visibility = Visibility.Hidden;
			SwipeImage.Visibility = Visibility.Hidden;
		}


        public CCSaleForm()
		{

		}

		public void DoSomething()
		{
			for (int i = 0; i < 1; i++)
			{
				this.Dispatcher.Invoke(() => {
					CCStatus.Content = "Authorizing";
				});
			}
		}

		private void SaleButton_Click(object sender, RoutedEventArgs e)
		{
			try
			{

                //new Thread(DoSomething).Start();
                //new Thread(DoSomething).Start();
                //uiThread.Send(delegate (object state)
                //	{
                //		CCStatus.Content = "Authorizing";
                //	}, null);

                if (ccClient.Sale())
				{
					GreenThumb.Visibility = Visibility.Visible;
					TxStatusLabel.Content = "Sale Successful";
					CCStatus.Content = "";
					SwipeImage.Visibility = Visibility.Hidden;
				}
				else
				{
					RedThumb.Visibility = Visibility.Visible;
					TxStatusLabel.Content = "Sale Failed";
					CCStatus.Content = "";
					SwipeImage.Visibility = Visibility.Hidden;
				}
			}
			catch (Exception ex)
			{

				throw ex;
			}

		}

		private void Manual_Entry_Click(object sender, RoutedEventArgs e)
		{
			ClearForm();
			CCStatus.Content = "Authorizing...";
			SwipeImage.Visibility = Visibility.Visible;
			if (ccClient.Sale(true))
			{
				GreenThumb.Visibility = Visibility.Visible;
				TxStatusLabel.Content = "Sale Successful";
			}
			else
			{
				RedThumb.Visibility = Visibility.Visible;
				TxStatusLabel.Content = "Sale Failed";
			}

			ClearForm();

		}

		private void CancelButton_Click(object sender, RoutedEventArgs e)
		{
			ClearForm();
		}

		public void ClearForm()
		{
			GreenThumb.Visibility = Visibility.Collapsed;
			RedThumb.Visibility = Visibility.Hidden;
			TxStatusLabel.Content = "";
		}

		private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
		{
			Application.Current.Shutdown();
		}

	}
}
