﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using com.clover.remotepay.sdk;
using com.clover.remotepay.transport;
using com.clover.remote.order;
using com.clover.sdk.v3.payments;

namespace iTicketCCProcessor.Infrastructure
{
	interface IProvider: ICloverConnectorListener
	{
        int Amount { get; set; }
        bool Sale();
		bool Sale(bool manualEntry);
		bool Credit(List<string[]> list, string connString, int dis);
		bool Void();
		bool InitializeDevice();
		bool InitializeDevice(CloverDeviceConfiguration config);
        bool GetProviderRequest();
		
	}
}
