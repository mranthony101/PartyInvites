﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using iTicketCCProcessor.Entities;
using iTicketCCProcessor.Infrastructure;
using com.clover.remotepay.transport;
using com.clover.remote.order;
using com.clover.sdk.v3.payments;
using ABP.Common.DAL.SqlServer;
using NLog;
using System.Data;
using System.Collections;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.ComponentModel;
using System.Windows.Threading;

namespace iTicketCCProcessor
{
	/// <summary>
	/// Interaction logic for CCRefundForm.xaml
	/// </summary>
	public partial class CCRefundForm : Window
	{
		string processorClient;
		IProvider ccClient;

		QueryHandler sqlHandler;
		QueryHandler handler;

        decimal begVal;

        bool fullRefund = false;

        string cloudDBString;

        int district;

        CloverDeviceConfiguration USBConfig = new USBCloverDeviceConfiguration("__deviceID__", "CloverExamplePOS:1.1.0.2", false, 1);

        private readonly BackgroundWorker proceedWorker = new BackgroundWorker();

		public CCRefundForm(string client)
		{
            DispatcherTimer checkVal = new DispatcherTimer();
            checkVal.Tick += new EventHandler(checkVal_Tick);
            checkVal.Interval = new TimeSpan(0, 0,1);
            checkVal.Start();

            InitializeDB();

            this.processorClient = client;
			InitializeComponent();

			if (processorClient.Equals("Clover"))
			{
				ccClient = new Clover(cloudDBString);
				ccClient.InitializeDevice(USBConfig);
				//MessageBox.Show("Clover");
			}
			else
			{
				ccClient = new Mock();
				ccClient.InitializeDevice();
				//MessageBox.Show("Mock");
			}
			InitializeDB();
            proceedWorker.DoWork += proceedWorker_DoWork;
			CCRefundDataGrid.ItemsSource = null;
			GetTransactionCCInfo();
			
		}

        private void proceedWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            this.Dispatcher.Invoke(() =>
            {
                if (decimal.Parse(AmountToRefundLbl.Content.ToString()) == decimal.Parse(RefundBalLbl.Content.ToString()))
                {
                    ProcessRefundButton.IsEnabled = true;
                }
                else
                {
                    ProcessRefundButton.IsEnabled = false;
                }
            });
           
        }

        private void checkVal_Tick(object sender, EventArgs e)
        {
            proceedWorker.RunWorkerAsync();
        }

        public void GetTransactionCCInfo()
		{
			try
			{
                DataTable cvTable = handler.ExecuteDataTable("SELECT * From CloverCVRequest");
                decimal refundAmt = cvTable.Rows[0].Field<decimal>("Amount");
                AmountToRefundLbl.Content = refundAmt.ToString("####.00");
                int txid = cvTable.Rows[0].Field<int>("TransactionID");
                string siteCode = cvTable.Rows[0].Field<string>("SiteCode");
                district = cvTable.Rows[0].Field<int>("District");
                
                if (FullTxRefund(refundAmt,siteCode, txid, district))
                {
                    fullRefund = true;
                }

                string ccInfoQuery = string.Format("select Account, Customer, Issuer, convert(money,Amount) as [Available Balance] " +
													"from d1_cc where sitecode = '{0}' and txid = {1}",
                                                    siteCode, txid);
                DataTable ccRefundTbl = sqlHandler.ExecuteDataTable(ccInfoQuery);

                ccRefundTbl.Columns.Add(new DataColumn("Amount To Refund", typeof(string)));
				ccRefundTbl.Columns.Add(new DataColumn("Selected", typeof(bool)));
				foreach(DataRow row in ccRefundTbl.Rows)
				{
                    string dec = row[3].ToString();
                    dec = dec.Substring(0,dec.Length - 2);
                    row[3] = dec;
                    if (fullRefund)
                    {
                        row[4] = row[3];
                        row[5] = true;
                        RefundBalLbl.Content = AmountToRefundLbl.Content;
                    }
                    else
                    {
                        row[5] = false;
                    }
				}

                ccRefundTbl.Columns[0].ReadOnly = true;
                ccRefundTbl.Columns[1].ReadOnly = true;
                ccRefundTbl.Columns[2].ReadOnly = true;
                ccRefundTbl.Columns[3].ReadOnly = true;


                CCRefundDataGrid.ItemsSource = ccRefundTbl.DefaultView;
				//AddColumns();

			}
			catch (Exception ex)
			{

				throw ex;
			}

		}

        private bool FullTxRefund(decimal amt, string site, int txid, int district)
        {
            try
            {
                string query = string.Format("Select sum(amount) from d{0}_cc where sitecode = '{1}' and txid = {2}", district, site, txid);
                decimal txTotal = sqlHandler.ExecuteScalar<decimal>(query);

                if (txTotal == amt)
                {
                    return true; 
                }
                else
                {
                    return false;
                }
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }

        public void InitializeDB()
		{
			try
			{
				cloudDBString = "Server=qa-service.iticketpos.com,5750;Database=AGSDev;User Id=manthony;Password=anthony101;";
				string localConfig = @"Data Source=.\SQLExpress;Initial Catalog=iTicketPOS;Integrated Security=True";
				handler = new QueryHandler(localConfig);
				DataTable configTbl = handler.ExecuteDataTable("Select * From ServiceSettings");

				string cloudServer = "Server=qa-service.iticketpos.com,5750";//configTbl.Rows[0].Field<string>("CloudServer");
				string cloudDB = "AGSDev";//configTbl.Rows[0].Field<string>("CloudDBName");
				string cloudUser = configTbl.Rows[0].Field<string>("POSUser");
				string cloudPW = configTbl.Rows[0].Field<string>("POSPw");

				cloudPW = Base64Decode(cloudPW);

				//cloudDBString = string.Format(cloudDBString, cloudServer, cloudDB, cloudUser, cloudPW);

				sqlHandler = new QueryHandler(cloudDBString);

			}
			catch (Exception ex)
			{

				throw ex;
			}
		}

		public static string Base64Decode(string base64EncodedData)
		{
			var base64EncodedBytes = System.Convert.FromBase64String(base64EncodedData);
			return System.Text.Encoding.UTF8.GetString(base64EncodedBytes);
		}


		public void AddColumns()
		{
			try
			{
				DataGridTextColumn remainingBalance = new DataGridTextColumn();
				remainingBalance.Header = "Remaining Balance";
				remainingBalance.DisplayIndex = 4;

				DataGridCheckBoxColumn selectBox = new DataGridCheckBoxColumn();
				selectBox.Header = "Select";
				selectBox.DisplayIndex = 5;
				CCRefundDataGrid.Columns.Add(selectBox);
				CCRefundDataGrid.Columns.Add(remainingBalance);
				CCRefundDataGrid.IsReadOnly = false;
			}
			catch (Exception ex)
			{

				throw ex;
			}
		}

        private void ProcessRefundButton_Click(object sender, RoutedEventArgs e)
        {
            ccClient.Credit(GetCardsToRefund(), cloudDBString, district);
        }

		private void ClearRefundButton_Click(object sender, RoutedEventArgs e)
		{

		}

        public List<string[]> GetCardsToRefund()
        {
            List<string[]> refundedCards = new List<string[]>();
            try
            {
                foreach (System.Data.DataRowView dr in CCRefundDataGrid.ItemsSource)
                {
                    if (dr[5].ToString().Equals("True"))
                    {
                        refundedCards.Add(new string[] { dr[0].ToString(), dr[1].ToString(), dr[2].ToString(), dr[3].ToString(), dr[4].ToString()});
                    }
                }
                return refundedCards;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        private void CCRefundDataGrid_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                decimal sum = 0;
                foreach (DataRowView dr in CCRefundDataGrid.ItemsSource)
                {
                    decimal amtVal = decimal.Parse(dr[3].ToString());
                    decimal currentVal = string.IsNullOrEmpty(dr[4].ToString()) ? 0 : decimal.Parse(dr[4].ToString());
                    if (currentVal <= amtVal)
                    {                        
                        sum = sum + currentVal; 
                    }
                    else
                    {
                        MessageBox.Show("You may not refund more than what is available\nOn the Available Balance", "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
                        dr[4] = 0;
                    }
                }
                RefundBalLbl.Content = sum;
                
            }
        }
    }
}
