﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Cal
{
	/// <summary>
	/// Interaction logic for MainWindow.xaml
	/// </summary>
	public partial class MainWindow : Window
	{
		List<Week> weekList = new List<Week>();
		public MainWindow()
		{
			InitializeComponent();

			GenerateCalender(DateTime.Now);
			Grid1.ItemsSource = weekList;

			


		}

		public void GenerateCalender(DateTime thisMonth)
		{
			Month1.Content = CultureInfo.CurrentCulture.DateTimeFormat.GetMonthName(thisMonth.Month) + " " + thisMonth.Year;

			var firstDayOfMonth = new DateTime(thisMonth.Year, thisMonth.Month, 1);

			int days = DateTime.DaysInMonth(thisMonth.Year, thisMonth.Month);
			int firstDay  = (int)firstDayOfMonth.DayOfWeek + 1;

			double hello = days / 7;
			int x = 1;
			int h = 0;
			bool start = false;

			for (int i = 1; i <= 6; i ++)
			{
				Week w = new Week();
				for(int j = 1; j <= 7; j ++)
				{
					if (i == 1)
					{
						if (j == firstDay)
						{
							switch (j)
							{
								case 1:
									w.Sunday = x + "\n\nAvail";
									x++;
									break;
								case 2:
									w.Monday = x + "\n\nPoop";
									x++;
									break;
								case 3:
									w.Tuesday = x + "\n\nAvail";
									x++;
									break;
								case 4:
									w.Wednesday = x + "\n\nPoop";
									x++;
									break;
								case 5:
									w.Thursday = x + "\n\nAvail";
									x++;
									break;
								case 6:
									w.Friday = x + "\n\nAvail";
									x++;
									break;
								case 7:
									w.Saturday = x + "\n\nPoop";
									x++;
									break;
							}
							start = true;
						}
						else if(start)
						{
							switch (j)
							{
								case 1:
									w.Sunday = x + "\n\nAvail";
									x++;
									break;
								case 2:
									w.Monday = x + "\n\nAvail";
									x++;
									break;
								case 3:
									w.Tuesday = x + "\n\nAvail";
									x++;
									break;
								case 4:
									w.Wednesday = x + "\n\nAvail";
									x++;
									break;
								case 5:
									w.Thursday = x + "\n\nPoop";
									x++;
									break;
								case 6:
									w.Friday = x + "\n\nAvail";
									x++;
									break;
								case 7:
									w.Saturday = x + "\n\nAvail";
									x++;
									break;
							}
						}						
					}
					else
					{
						switch (j)
						{
							case 1:
								w.Sunday = x + "\n\nAvail";
								x++;
								break;
							case 2:
								w.Monday = x + "\n\nPoop";
								x++;
								break;
							case 3:
								w.Tuesday = x + "\n\nAvail";
								x++;
								break;
							case 4:
								w.Wednesday = x + "\n\nAvail";
								x++;
								break;
							case 5:
								w.Thursday = x + "\n\nPoop";
								x++;
								break;
							case 6:
								w.Friday = x + "\n\nAvail";
								x++;
								break;
							case 7:
								w.Saturday = x + "\n\nPoop";
								x++;
								break;
						}
					}
					if (x == days + 1)
					{
						h = 1;
						break;
					}

				}
				weekList.Add(w);
				if (h == 1)
				{
					break;
				}
			}

		}

	}

	public class Week
	{
		public string Sunday { get; set; }

		public string Monday { get; set; }

		public string Tuesday { get; set; }

		public string Wednesday { get; set; }

		public string Thursday { get; set; }

		public string Friday { get; set; }

		public string Saturday { get; set; }
	}
}

